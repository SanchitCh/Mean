sampleApp.controller('BookingController', function($scope) {

	$scope.tagline = 'Book your movies here!';

});